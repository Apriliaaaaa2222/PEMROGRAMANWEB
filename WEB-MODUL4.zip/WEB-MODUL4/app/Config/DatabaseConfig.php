<?php

namespace app\Config;

class DatabaseConfig
{
    public $host = "Localhost";
    public $user = "root";
    public $password = "";
    public $database_name = "codelab4";
    public $port = 3306;
}